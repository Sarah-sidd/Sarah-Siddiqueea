<!DOCTYPE html>
<html>
<head></head>
<body>
	<div>

  <div class="row">
  <div class="column-left">
  <div class="panel panel-primary">
      <div class="panel-heading">English PDF</div>
      <div class="panel-body">
      <div class="panel-body">CSS</div>
  </div>
  </div>
  
		<?php
		require_once 'connection.php';

		$qry = $conn->query( "select * from file");

		foreach ($qry as $key => $value) {

			echo '<a  href="' .$value["src"]. '"><h3>click</h3> </a>';
		}
	?>
</div>
</body>
</html>



<div class="row">
  <div class="column-left">
  <div class="panel panel-primary">
      <div class="panel-heading">English PDF</div>
      <div class="panel-body">
      <div class="panel-body">CSS</div>
  </div>
  </div>

  <div class="column-right">
  <div class="panel panel-primary">
      <div class="panel-heading">Bangla PDF</div>
      <div class="panel-body">HTML</div>
      <div class="panel-body">CSS</div>
  </div>
  </div>
</div>