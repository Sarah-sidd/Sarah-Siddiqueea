

<?php
error_reporting(0);
mysql_connect("localhost","root","");
mysql_select_db("my");
$name=$_POST['name'];
$comment=$_POST['comment'];
$submit=$_POST['submit'];
 
$dbLink = mysql_connect("localhost", "root", "");
    mysql_query("SET character_set_client=utf8", $dbLink);
    mysql_query("SET character_set_connection=utf8", $dbLink);
 
if($submit)
{
if($name&&$comment)
{
$insert=mysql_query("INSERT INTO commenttable (name,comment) VALUES ('$name','$comment') ");
echo "<meta HTTP-EQUIV='REFRESH' content='0; url=commentindex.php'>";
}
else
{
echo "please fill out all fields";
}
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Contact.com</title>
<link rel="stylesheet" type="text/css" href="style.css"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style type="text/css">


.w3-container w3-red .column{
  float: left;
    padding: 10px;
    height: 300px;
  }

.column {
    float: left;
    width: 20%;
    height: 470px;
    margin-left: -10px;
}
/*.left{
    width: 20%;
    height: 552px;
    margin-top: -60px;
    margin-left: 1px;
}*/
.middle{
    width: 40%;
    margin-left: 350px;

}
.right{
    width: 40%;
    margin-left: 700px;
    margin-top:-500px;

}

    
    .row:after {
    content: "";
    display: table;
    clear: both;
}
</style>
</head>
<body>
	


<div class="container">
  <a href="mt2.php">Home</a>
  
  <div class="dropdown">
    <button  class="dropbtn">About</button>
    <div class="dropdown-content">
      <a href="vision.php#who">Vision</a>
      <a href="contactmy.php">Contact</a>
    </div>
  </div> 
  <a href="new.php">Feature</a>
  <a href="signup.php">Sign Up</a>
  <a href="mainlogin.php">Login</a>
   <h2 style="float: right; margin-right: 50px;"><span style="color: SkyBlue;">Uapians</span> WebDev</h2>
   <img style="float:right" src="images/web8.jpg" width="50px" height="50px";>

</div>

<h6 style="margin-left: 500px;color: OrangeRed;">For any query please fill up this form that given below</h6>


<center>
<form action="contactmy.php" method="POST">
<table>
<tr><td>Name: <br><input style="padding:10px 30px;border:1px solid #ccc;border-color: Yellowgreen;border-radius: 5px;"  type="text" name="name"/></td></tr>
<tr><td colspan="2">Massage: </td></tr>
<tr><td colspan="5"><textarea style="height:250px;width: 470px; border-color: Yellowgreen;" name="comment" rows="10" cols="50"></textarea></td></tr>
<tr><td colspan="2"><input style="width: 20%;
            height: 30px;
            margin: 8px 0;
            display: inline-block;
            border-radius: 5px;
            background-color: #4CAF50;
            border:none;
            cursor: pointer;" type="submit" name="submit" value="Done"></td></tr>
</table>
</form>
</center>


 

    

    <?php
$dbLink = mysql_connect("localhost", "root", "");
    mysql_query("SET character_set_results=utf8", $dbLink);
    mb_language('uni');
    mb_internal_encoding('UTF-8');
 
$getquery=mysql_query("SELECT * FROM commenttable ORDER BY id DESC");
while($rows=mysql_fetch_assoc($getquery))
{
$id=$rows['id'];
$name=$rows['name'];
$comment=$rows['comment'];
echo $name . '<br/>' . '<br/>' . $comment . '<br/>' . '<br/>' . '<hr size="1"/>'
;}
?>

<div style="margin-top: 30px;" class="w3-container w3-red">
  <div class="row">
    <div class="column1"><h5 style="margin-left: 50px"><i class="fa fa-cab" style="font-size:24px"><h6 style="margin-top: -20px;margin-left: 30px">74/A, Green Road, Farmgate, Dhaka - 1215, Bangladesh</h6></i></h5>
    </div>

   <div class="column2"><h5 style="margin-left: 50px;margin-bottom: -50px"><i class="fa fa-volume-control-phone" style="font-size:24px"><h6 style="margin-top: -20px;margin-left: 30px">+8802-58157091</h6></i></h5>
   </div>

   <div class="column3"><h5 style="margin-left: 1100px;margin-top: -70px">Join us on</br><i><a href="https://www.facebook.com/groups/156822664897462/" class="fa fa-facebook-official" style="font-size:24px"></a> </i></h5>
   </div>
</div>
<div>
 <h6 style="margin-left: 600px"> &copy 2018, All Rights Reserved</h6>
</div>
      

</body>
</html>
