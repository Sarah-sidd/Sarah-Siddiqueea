<?php
require_once 'connection.php'; /*conncetion file call krbe*/

/*$i_n=$_REQUEST['S_id'];*/ 
$n_n=$_REQUEST['name'];
$e_n=$_REQUEST['email'];
$p_n=$_REQUEST['pass'];
$g_n=$_REQUEST['gender'];
$c_n=$_REQUEST['cname'];
$o_n=$_REQUEST['phone'];

//echo $n_n."</br>";//dile show korbe insert page e 

$sql = "insert into my.signup(Name,Email,Password,Gender,Course_name,Contact)
VALUES ('$n_n','$e_n','$p_n','$g_n','$c_n','$o_n')";
//echo $sql;
if(mysqli_query($conn,$sql))
{
  echo "Records  added Successfully.";
}
else
{
  echo "Error: could not able to execute $sql.". mysqli_error($conn);
}
mysqli_close($conn);

?>
