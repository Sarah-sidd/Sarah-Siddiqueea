 <?php
 
 $host="localhost";
 $user="root";
 $password="";
 $db="my";

 mysql_connect($host,$user,$password);
 mysql_select_db($db);


 if(isset($_POST['Email'])){

 	$Email=$_POST['Email'];
 	$Password=$_POST['Password'];


 	$sql="select * from signup where Email= '".$Email."'AND Password='".$Password."' limit 1";

 	$result = mysql_query($sql);

 	if(mysql_num_rows($result)==1){
 		session_start();
 		$_SESSION['sess_user']="user";
 		header("location:msg.php");
 	}

 	else{
 		echo "incorrect";
 		header("location:user.php");
 	}
 }

?>
