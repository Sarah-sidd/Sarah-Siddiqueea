<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
 
</head>
<body >

	
	<div class="container">
  <a href="mt2.php">Home</a>
  
  <div class="dropdown">
    <button class="dropbtn">About</button>
    <div class="dropdown-content">
      <a href="vision.php#who">Vision</a>
      <a href="contactmy.php">Contact</a>
    </div>
  </div>
  <a href="new.php">Feature</a>

  <a href="mainlogin.php">login</a>
  <a href="signup.php">sign up</a>
</div>


</body>
</html>