<!DOCTYPE html>
<html>
<head>
	<title>log.com</title>
	<link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
  <style type="text/css">

  body {
    background-image: url("images/login.jpg");
    background-repeat: no-repeat;
    height: 100%;
    background-size: cover;

}
/*
  .col{
    float: left;
    width: 30%;
    margin-left: 200px;
}*/


 /*.left{
  float: left;
  width: 20%;
  height: 530px;
  margin-left: 1px;
  margin-top: -150px;
}
.right{
  margin-left: 600px;
  margin-top: 150px;
}
    .row:after {
    content: "";
    display: table;
    clear: both;
}*/
.w3-container w3-red{
  float: left;
    padding: 10px;
    height: 300px;
    margin-top: 400px;
  }

  </style>
</head>
<body>
    
    
    <div class="container">
  <a href="mt2.php">Home</a>
  
  <div class="dropdown">
    <button class="dropbtn">About</button>
    <div class="dropdown-content">
      <a href="vision.php#who">Vision</a>
      <a href="contactmy.php">Contact</a>
    </div>
  </div> 
  <a href="new.php">Feature</a>
  <a href="signup.php">Sign Up</a>
   <a href="mainlogin.php">Login</a>
  <h2 style="float: right; margin-right: 50px;"><span style="color: SkyBlue;">Uapians</span> WebDev</h2>
   <img style="float:right" src="images/web8.jpg" width="50px" height="50px";>

</div>

<div>
  <div style="margin-top:200px; margin-left: 400px" class="col">
  <a href="admin.php"><img src="images/admin.jpg"></a>
   </br><h3>ADMIN</h3>
  </div>
  <div style="margin-bottom: 600px;margin-left: 800px;margin-top: -310px" class="col">
   <a href="user.php"> <img src="images/user.jpg"></a></br><h3>USER</h3>
  </div>
</div>

               
<!-- <div class="row">
 <div class="column left" style=" font-size:25px;padding: 5px ;background-color: #303030;">
    		<h1 style="color: Aquamarine"></h1><br>
    		<h1 style="color:Aquamarine">Thank you! For choosing us</h1>
        <i class="fa fa-thumbs-up" style="font-size: 51px;color: LightSalmon"></i>
    	</div> 

<div class="column right">
	<label>
	Your Name
    </label><br>
    <input style="padding:10px 75px;border:1px solid #ccc;border-color: green;border-radius: 5px" type="text" name="Full name" placeholder="">
   <label><br>
   	User Email
    </label><br>
    <input style="padding:2px 5px;border:1px solid #ccc;border-color: green;border-radius: 5px" type="email" name="mail" placeholder="" ><br>
    <form action="msg.html">
    <input type="Submit" name="Submit" value= "GO"></form><br>
    <a href="msg.html">Don't Have Any Account?Sign Up!</a>

</div>
</div> -->
<!-- <div style="position: relative;">
<img src="images/clr3.jpg" width="100%" height="80px"> <div class="center" style="position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    font-size: 18px;">Copyright 2017, All Rights Reserved</div>
    <div class="topleft" style="position: absolute;top:20px;left:50px; 
    font-size: 18px; width: 25%">74/A, Green Road, Farmgate, Dhaka - 1215, Bangladesh
PABX:+8802-58157091</div> -->
      

<div  style="margin-top: -150px" class="w3-container w3-red">
  <div class="row">
    <div class="column left"><h5 style="margin-left: 50px"><i class="fa fa-cab" style="font-size:24px"><h6 style="margin-top: -20px;margin-left: 30px">74/A, Green Road, Farmgate, Dhaka - 1215, Bangladesh</h6></i></h5>
    </div>

   <div class="column middle"><h5 style="margin-left: 50px"><i class="fa fa-volume-control-phone" style="font-size:24px"><h6 style="margin-top: -20px;margin-left: 30px">+8802-58157091</h6></i></h5>
   </div>

   <div class="column right"><h5 style="margin-left: 1100px;margin-top: -70px">Join us on</br><i><a href="https://www.facebook.com/groups/156822664897462/" class="fa fa-facebook-official" style="font-size:24px"></a> </i></h5>
   </div>
 </div> 
 <h6 style="margin-left: 600px"> &copy 2018, All Rights Reserved</h6>
</div>
</body>
</html>



