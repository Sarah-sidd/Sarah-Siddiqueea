<?php
session_start();
if(!isset($_SESSION["sess_user"])){
	header("location:login1.php");
}else{

?>

<html>
<head>
	<title></title>
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


	<style>
		body{
			background: url("images/background1.jpg") no-repeat;
			background-size: 100% 700px;
		}

		p{
			text-align: center;
			font-style: solid;
			margin-top: 200px;
			color: black;
			font-size: 25px;
		}
		.container{
			text-align: center;
		}
	</style>
</head>
<body>

	<div  class="container">
    <a style="margin-left: 1150px;" href="logout.php" class="btn btn-danger" role="button">Logout</a>


	<p class="text-muted">Welcome To Our Learning Session!</p>

	<div class="container">
    <a href="new.php" class="btn btn-danger" role="button">Get Started</a>
    </div>
    

</body>
</html>
<?php
}
?>