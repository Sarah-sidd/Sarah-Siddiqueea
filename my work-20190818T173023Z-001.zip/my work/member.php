<?php
error_reporting(0);
require_once 'connection.php';

$sql = "SELECT * FROM signup";
$result = mysqli_query($conn,$sql);

?>

<?php
session_start();
if(!isset($_SESSION["sess_admin"])){
  header("location:login.php");
}else{

?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
   
</head>

<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial;
}

.search-container {
  overflow: hidden;
  
}
.search-container {
  float: right;
}
.search-container input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}
.search-container button:hover {
  background: #ccc;
}

</style>
<body>
 <div class="container">
  <a href="mt2.php">Home</a>
  
  <div class="dropdown">
    <button class="dropbtn">About</button>
    <div class="dropdown-content">
      <a href="vision.php#who">Vision</a>
      <a href="contactmy.php">Contact</a>
    </div>
  </div> 
  <a href="new.php">Feature</a>
 <a href="signup.php">Sign Up</a>
   <a href="mainlogin.php">Login</a>
  <h2 style="float: right; margin-right: 50px;"><span style="color: SkyBlue;">Uapians</span> WebDev</h2>
   <img style="float:right" src="images/web8.jpg" width="50px" height="50px";>

</div>

<!-- search -->

<div class="search-container">
  <form name ='search' action="" method='POST'>
    <input type="text" placeholder="Search.." name="keyword">
    <button type="submit" name="btnsearch" value="Search"><i class="fa fa-search"></i></button>
  </form>
</div>
<div>
    <h1 style="margin-left: 600px ;color: Blue;">
      Members
    </h1>
</div> 
<button style="margin-bottom:-20px; margin-left:30px; margin-top: -20px; " class="button" value="submit">Logout</button><br>
   </form>    


 <?php
}
?>

  <?php 

  echo "<table align=center style='width: 60%; border-collapse: 2px solid grey;'>
  <tr style='border: 2px solid Black; color: RebeccaPurple;'>
    <th style='border: 2px solid Black; color: RebeccaPurple;'>Fullname</th>
    <th style='border: 2px solid Black; color: RebeccaPurple;'>Email</th>
    <th style='border: 2px solid Black; color: RebeccaPurple;'>Password</th>
    <th style='border: 2px solid Black; color: RebeccaPurple;'>Gender</th>
    <th style='border: 2px solid Black; color: RebeccaPurple;'>Course</th>
    <th style='border: 2px solid Black; color: RebeccaPurple;'>Phone</th>
  </tr>";


  //search

$sql = "SELECT * from signup";
    
if($_POST['btnsearch']=="Search")
{
  $key=$_POST['keyword'];
 print $sql=$sql. " where Name like '%$key%'";

  
}
$result = mysqli_query($conn,$sql);

$i=1; 



while($row = mysqli_fetch_array($result)) {

  $Fullname=$row['Name'];
  $Email=$row['Email'];
  $Password=$row['Password'];
  $Gender=$row['Gender'];
  $Course=$row['Course_name'];
  $Phone=$row['Contact'];
  

echo"<tr style='border: 2px solid Black; text-align: center; color: RebeccaPurple;'>
    <td style='border: 2px solid Black; color: RebeccaPurple;'>$Fullname</td>
    <td style='border: 2px solid Black; color: RebeccaPurple;'>$Email</td>
    <td style='border: 2px solid Black; color: RebeccaPurple;'>$Password</td>
    <td style='border: 2px solid Black; color: RebeccaPurple;'>$Gender</td>
    <td style='border: 2px solid Black; color: RebeccaPurple;'>$Course</td>
    <td style='border: 2px solid Black; color: RebeccaPurple;'>$Phone</td>
  </tr>";

}

echo "</table>";
$conn->close();
?>



</body>
</html>