

<!DOCTYPE html>
<html>
<head>
	<title>Sign Up.com</title>
	<link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
</head>
<style>

</style>
<body>
   
           
    
    <div class="container">
  <a href="mt2.php">Home</a>
  
  <div class="dropdown">
    <button class="dropbtn">About</button>
    <div class="dropdown-content">
      <a href="vision.php#who">Vision</a>
      <a href="contactmy.php">Contact</a>
    </div>
  </div> 
  <a href="new.php">Feature</a>
  <a href="signup.php">Sign Up</a>
   <a href="mainlogin.php">Login</a>
  <h2 style="float: right; margin-right: 50px;"><span style="color: SkyBlue;">Uapians</span> WebDev</h2>
   <img style="float:right" src="images/web8.jpg" width="50px" height="50px";>

</div>

<div style ="margin-bottom: 30px;" class="box">
    <img style="border: none;margin-top: 70px;" src="images/Web3.jpg" width="40%" height="500px";>
</div>

<div id="form_div">


<h1 style="margin-left:10px; color: tomato;">
	Sign Up Form
</h1>	
<form id="form1" action="insert.php" method="post">
	User Name
    </label><br>
    <input type="text" name="name" placeholder="type your name">
   <label><br>
    User Email
    </label><br>
    <input type="email" name="email" placeholder="enter your email">
    <label><br>
	Password
    </label><br>
    <input type="Password" name="pass" placeholder="enter your Password">
    <label><br>
    Gender
    </label><br>
    	
    	<input type="radio" name="gender" value="Male" checked="true">Male<br>
    	<input type="radio" name="gender" value="Female" checked="false">Female
    <label><br>
    Course
    </label><br>

    <input type="radio" name="cname" checked="true" value="HTML">HTML
    <input type="radio" name="cname" checked="false" value="CSS">CSS


    <label><br>
    	Contact
    </label><br>
    <input type="num" name="phone" placeholder="enter a valid number"><br>

   <button class="button" value="submit" formaction="mainlogin.php">Submit</button><br>
   </form>    
</div>

        
    </div>

<div class="w3-container w3-red">
  <div class="row">
    <div class="column left"><h5 style="margin-left: 50px"><i class="fa fa-cab" style="font-size:24px"><h6 style="margin-top: -20px;margin-left: 30px">74/A, Green Road, Farmgate, Dhaka - 1215, Bangladesh</h6></i></h5>
    </div>

   <div class="column middle"><h5 style="margin-left: 50px"><i class="fa fa-volume-control-phone" style="font-size:24px"><h6 style="margin-top: -20px;margin-left: 30px">+8802-58157091</h6></i></h5>
   </div>

   <div class="column right"><h5 style="margin-left: 1100px;margin-top: -70px">Join us on</br><i><a href="https://www.facebook.com/groups/156822664897462/" class="fa fa-facebook-official" style="font-size:24px"></a> </i></h5>
   </div>
 </div>
 <h6 style="margin-left: 600px"> &copy 2018, All Rights Reserved</h6>
</div>
</body>
</html>