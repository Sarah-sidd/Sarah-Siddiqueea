<!DOCTYPE html>
<html>
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<style>
		body{
			background: url("images/web-app.jpg") no-repeat;
			background-size: 100% 800px;
		}
		h1{
			text-align: center;
			margin-top: 40px;
		}



.sidenav {
    display: none;
    height: 100%;
    width: 300px;
    position: fixed; /sidenav fixed thakbe
    z-index: 1;
   background-color: #111;
    overflow-x: hidden;
    
}
.sidenav a {
    padding: 5px 5px 5px 5px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
}
  .sidenav a:hover {
    color: tomato;
}


	</style>
</head>

<body>

<!-- Sidebar -->
<div class="row">
  <div class="column-left">
<div class="sidenav" style="display:none" id="mySidebar">
  <button onclick="w3_close()" class="w3-bar-item w3-button w3-large">&times;</button>
  <a href="#" class="w3-bar-item w3-button">About Us</a>
  <a href="#" class="w3-bar-item w3-button">Feature</a>
  <a href="doners reg.html" class="w3-bar-item w3-button">Want To Be A Doner?</a>
  <a href="#" class="w3-bar-item w3-button">Login</a>
  <a href="#" class="w3-bar-item w3-button">Contact</a>
</div>
</div>

<div class="column-right">
<div class="Course">
		
		<h1>Course Outline</h1>
</div>
 
<div class="container">  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!--  carosuel slide css er effect create krbe..data ride tells bootstrap for animation-->
    <ol class="carousel-indicators"><!--indicator holo dots    data target krbe id ta.. slide to holo nxt kon slide e jabe seta-->
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
    </ol>

    <!-- class active na rakhle nxt gulo visible hbena -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="images/html.jpg" alt="Basic level's web developer?Try HTML" style="width:100%; height: 500px;">
      </div>

      <div class="item">
        <img src="images/cs.jpg" alt="Chicago" style="width:100%;height: 500px;">
      </div>
    
      
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
</div>

<script>
function w3_open() {
    
    document.getElementById("mySidebar").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
}
</script>
</body>
</html>