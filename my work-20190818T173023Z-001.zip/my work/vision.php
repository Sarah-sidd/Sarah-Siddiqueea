<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<style type="text/css">
	
body {
    background-image: url("images/header.jpg");
    background-repeat: no-repeat;
}

.w3-container w3-red .column{
  float: left;
    padding: 10px;
    height: 300px;
  }
	</style>
</head>
<body> 

<div class="container">
  <a href="mt2.php">Home</a>
  
  <div class="dropdown">
    <button  class="dropbtn">About</button>
    <div class="dropdown-content">
      <a href="vision.php#who">Vision</a>
      <a href="contactmy.php">Contact</a>
    </div>
  </div>
  <a href="new.php">Feature</a>
  <a href="signup.php">Sign Up</a>
  <a href="mainlogin.php">Login</a>
   <h2 style="float: right; margin-right: 50px;"><span style="color: SkyBlue;">Uapians</span> WebDev</h2>
   <img style="float:right" src="images/web8.jpg" width="50px" height="50px";>

</div>

<div style="margin-top: 150px;text-align: center;">
  <h1 style="font-family: serif; color: white;">To become a prime performer in the global marketplace by providing highly innovative web designing, web development and internet marketing services that will drive our clients' business towards growth. Worldwide reputation is the dream of every company and we want to achieve it through our work.</h1>
</div>

<div style="margin-top: 108px;" class="w3-container w3-red">
  <div class="row">
    <div class="column left"><h5 style="margin-left: 50px"><i class="fa fa-cab" style="font-size:24px"><h6 style="margin-top: -20px;margin-left: 30px">74/A, Green Road, Farmgate, Dhaka - 1215, Bangladesh</h6></i></h5>
    </div>

   <div class="column middle"><h5 style="margin-left: 50px"><i class="fa fa-volume-control-phone" style="font-size:24px"><h6 style="margin-top: -20px;margin-left: 30px">+8802-58157091</h6></i></h5>
   </div>

   <div class="column right"><h5 style="margin-left: 1100px;margin-top: -70px">Join us on</br><i><a href="https://www.facebook.com/groups/156822664897462/" class="fa fa-facebook-official" style="font-size:24px"></a> </i></h5>
   </div>
 </div>
 <h6 style="margin-left: 600px"> &copy 2018, All Rights Reserved</h6>
</div>
</body>
</html>