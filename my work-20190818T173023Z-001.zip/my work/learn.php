<!DOCTYPE html>
<html>
<head>
	<title>uap.com</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
 
	
	<div class="container">
  <a href="mt2.php">Home</a>
  
  <div class="dropdown">
    <button  class="dropbtn">About</button>
    <div class="dropdown-content">
      <a href="about.php#who">Vision</a>
      <a href="about.php#info">Member</a>
    </div>
  </div> 
  <a href="contactmy.php">Contact</a>

  <a href="new.php">Feature</a>
  <a href="signup.php">Sign Up</a>
   <a href="mainlogin.php">Login</a>
   <h2 style="float: right; margin-right: 50px;"><span style="color: SkyBlue;
   ">Uapians</span> WebDev</h2>
    <img style="float:right" src="images/web8.jpg" width="50px" height="50px";>

 </div>
 <div>
   
 </div>
 </body>
 </html>
