
<?php
session_start();
if(!isset($_SESSION["sess_user"])){
  header("location:login1.php");
}else{

?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<style>
		/*body{
			background: url("images/web-app.jpg") no-repeat;
			background-size: 100% 800px;
		}*/
		h1{
			text-align: center;
			margin-top: 40px;
		}

 .column-left {
    width: 30%;
    margin-left: 120px;
    margin-top: 20px;

  }

  .column-right {
    width: 100%;
    margin-left: 700px;
    margin-top: -180px;
  }

	</style>
</head>

<body>
<div class="container">
  <a href="mt2.php">Home</a>
  
  <div class="dropdown">
    <button  class="dropbtn">About</button>
    <div class="dropdown-content">
      <a href="vision.php#who">Vision</a>
      <a href="contactmy.php">Contact</a>
    </div>
  </div> 
  <a href="new.php">Feature</a>
  <a href="signup.php">Sign Up</a>
  <a href="mainlogin.php">Login</a>
   <h2 style="float: right; margin-right: 50px;"><span style="color: SkyBlue;">Uapians</span> WebDev</h2>
   <img style="float:right" src="images/web8.jpg" width="50px" height="50px";>

</div>

<div  class="container1">
    <a style="margin-left: 1270px;margin-top: 10px;" href="logout.php" class="btn btn-danger" role="button">Logout</a>
<div class="Course">
		
		<h1>Course Outline</h1></a>
</div>
 
<div class="Cou">  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!--  carosuel slide css er effect create krbe..data ride tells bootstrap for animation-->
    <ol class="carousel-indicators"><!--indicator holo dots    data target krbe id ta.. slide to holo nxt kon slide e jabe seta-->
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
    </ol>

    <!-- class active na rakhle nxt gulo visible hbena -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="images/ht.jpg" alt="Basic level's web developer?Try HTML" style="width:100%; height: 500px;">
      </div>

      <div class="item">
        <img src="images/css.jpg" alt="Chicago" style="width:100%;height: 500px;">
      </div>
    
      
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<div>
  <h1 style="text-align: center;"> PDF</h1>
</div>

<div>

  <div class="row">
  <div class="column-left">
  <div class="panel panel-primary">
      <div class="panel-heading">English PDF</div>
      <div class="panel-body">
      <div class="panel-body">HTML and CSS design and build websites</div>
  </div>
  </div>
  
    <?php
    require_once 'connection.php';

    $qry = $conn->query( "select * from file");

    foreach ($qry as $key => $value) {

      echo '<a  href="' .$value["src"]. '"><h3 style=margin-left:10px;>Download</h3> </a>';
    }
  ?>



<iframe style="margin-top: 20px;" width="560" height="315" src="https://www.youtube.com/embed/dD2EISBDjWM" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>


<iframe style="margin-bottom: 100px; margin" width="560" height="315" src="https://www.youtube.com/embed/qKoajPPWpmo" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

</body>
</html>
<?php
}
?>