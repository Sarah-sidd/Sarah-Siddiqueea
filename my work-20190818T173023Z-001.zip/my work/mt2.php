<!DOCTYPE html>
<html>
<head>
	<title>uap.com</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<style>


.w3-container w3-red .column{
  float: left;
    padding: 10px;
    height: 300px;
  }
</style>
<body>
 
	
<div class="container">
  <a href="mt2.php">Home</a>
  
  <div class="dropdown">
    <button  class="dropbtn">About</button>
    <div class="dropdown-content">
      <a href="vision.php#who">Vision</a>
      <a href="contactmy.php">Contact</a>
    </div>
  </div> 
  <a href="new.php">Feature</a>
  <a href="signup.php">Sign Up</a>
  <a href="mainlogin.php">Login</a>
   <h2 style="float: right; margin-right: 50px;"><span style="color: SkyBlue;">Uapians</span> WebDev</h2>
   <img style="float:right" src="images/web8.jpg" width="50px" height="50px";>

</div>

<center>
<img src="images/web7.jpg" style="width: 1100px; height: 350px">	
</center>

<div class="row">
	 
	<div class="column1 lef" style="width: 25%;">
		<h1 style="font-size: 60px; font-style: oblique;margin-top: 200px;margin-left: 150px;color:tomato"><p style=" border-style: hidden;
    border-right: solid green;margin-right:-220px;">Web Development</p></h1>
	</div>

	<div class="column1 rig" style="width: 90%;height: 30px;margin: 5px 5px 5px 5px;">
		<p style="margin-top: -270px;margin-left: 700px;font-size: 22px;">Now-a-days people learn web developing with passion.web development, is the creation of dynamic web applications.If you have decided not to build your own website, you may already know that you will need a web developer who will make sure the technical side of your new website by developing your site.
		</p>
	</div>
</div>

<div class="row">

	<div class="column" style="width: 20%;">
		<h1 style="font-size: 60px; font-style: oblique;margin-top: 300px;margin-left: 130px;color:tomato">
		   <p style=" border-style: hidden;border-right: solid green;margin-right:-200px;margin-bottom: 50px">Our Mission
		   </p>
	    </h1>
	</div>

	<div class="column" style="width: 70%;height: 10px;">
		<p style="margin-top: -160px;margin-left: 500px;font-size: 22px;">Our mission is designed to start you on a path toward future studies in web development and design, no matter how little experience or technical knowledge you currently have.
        </p>
	</div>

	<div class="column" style="width: 10%">
		<img style="margin-left: 940px;margin-top: -100px;" src="images/web5.jpg" width="300%" height="300px";>
	</div>
</div>

<div class="w3-container w3-red">
  <div class="row">
    <div class="column left"><h5 style="margin-left: 50px"><i class="fa fa-cab" style="font-size:24px"><h6 style="margin-top: -20px;margin-left: 30px">74/A, Green Road, Farmgate, Dhaka - 1215, Bangladesh</h6></i></h5>
    </div>

   <div class="column middle"><h5 style="margin-left: 50px"><i class="fa fa-volume-control-phone" style="font-size:24px"><h6 style="margin-top: -20px;margin-left: 30px">+8802-58157091</h6></i></h5>
   </div>

   <div class="column right"><h5 style="margin-left: 1100px;margin-top: -70px">Join us on</br><i><a href="https://www.facebook.com/groups/156822664897462/" class="fa fa-facebook-official" style="font-size:24px"></a> </i></h5>
   </div>
 </div>
 <h6 style="margin-left: 600px"> &copy 2018, All Rights Reserved</h6>
</div>

</body>
</html>
