 <?php
 
 $host="localhost";
 $user="root";
 $password="";
 $db="my";

 mysql_connect($host,$user,$password);
 mysql_select_db($db);


 if(isset($_POST['uname'])){

 	$uname=$_POST['uname'];
 	$password=$_POST['password'];


 	$sql="select * from adlogin where uname= '".$uname."'AND password='".$password."' limit 1";

 	$result = mysql_query($sql);

 	if(mysql_num_rows($result)==1){
 		session_start();
 		$_SESSION['sess_admin']="admin";
 		header("location:member.php");
 	}

 	else{
 		echo "incorrect";
 		header("location:login.php");
 	}
 }

?>
